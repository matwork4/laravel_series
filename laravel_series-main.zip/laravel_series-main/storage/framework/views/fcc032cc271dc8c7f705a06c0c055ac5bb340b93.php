<?php $__env->startSection('content'); ?>
<h1>Profile</h1>
<p>Username : <?php echo e($user->username); ?></p>
<p>Nom : <?php echo e($user->name); ?></p>
<!-- On affiche le titre des séries -->
<p>Mes séries : 
    <?php $__currentLoopData = $user->serie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <br>
        <button class="btn btn-primary"
        onclick="location.href='/series/<?php echo e($s->id); ?>'">
            <?php echo e($s->title); ?>

        </button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>
        
<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/icm1/ruffieum/Documents/cours web/cote serveur/laravel_projects/laravel_series-main/resources/views/profile.blade.php ENDPATH**/ ?>