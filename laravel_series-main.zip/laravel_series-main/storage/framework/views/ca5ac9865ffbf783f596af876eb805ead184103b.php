<?php $__env->startSection('content'); ?>
<div class="div_menu">
    <h1>Main Menu</h1>

    <?php if(auth()->guard()->guest()): ?>
        <p>Bienvenue !</p>
        <p>Cliquez ici pour vous connecter : 
            <button class="btn btn-primary"
            onclick="location.href='/login'">
            Se connecter</button></p>
        <p>ou</p>
    <?php else: ?>
        <p>Vous êtes connecté ! </p>
        <p>Bienvenue <?php echo e(Auth::user()->username); ?></p>
    <?php endif; ?>

    <p>Cliquez ici pour accéder aux séries : 
        <button class="btn btn-primary"
        onclick="location.href='/series'">Voir
    </button></p>


</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/icm1/ruffieum/Documents/cours web/cote serveur/laravel_projects/laravel_series-main/resources/views/menu.blade.php ENDPATH**/ ?>