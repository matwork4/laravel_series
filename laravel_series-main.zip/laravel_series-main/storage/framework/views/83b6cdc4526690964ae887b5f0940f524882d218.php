        



<?php $__env->startSection('content'); ?>
<h1>Contacts</h1>
        
<p>Liste des administrateurs à contacter :  
    <?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $u): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <br>
        <p><?php echo e($u->username); ?></p>
        <button class="btn btn-primary"
        onclick="location.href='#'">
            Contacter
        </button>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/icm1/ruffieum/Documents/cours web/cote serveur/laravel_projects/laravel_series-main/resources/views/contact.blade.php ENDPATH**/ ?>