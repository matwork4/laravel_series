<?php $__env->startSection('content'); ?>

<?php if(auth()->guard()->guest()): ?>
    <p>Connectez vous pour ajouter une série : 
        <button class="btn btn-primary"
        onclick="location.href='/login'">
        Se connecter</button></p>
            
<?php else: ?>
            
    <form action="/s_store" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <h3>Ajouter une série</h3><br>
        <p>Titre :</p><br>
        <input type="text" id="title" name="title" value=""><br>
        <p>Description :</p><br>
        <input type="text" id="description" name="description" value=""><br>
        <p>Acteurs :</p><br>
        <input type="text" id="actors" name="actors" value=""><br>
        <p>Tags :</p><br>
        <input type="text" id="tags" name="tags" value=""><br>
        <p>URL de la bande annonce :</p><br>
        <input type="text" id="url_video" name="url_video" value=""><br>

        <p>Image de l'affiche du film :</p>
        <input type="file" class="form-control-file" id="image_miniature" name="image_miniature"><br>
        <?php if($errors->has('image_miniature')): ?>
            <strong><?php echo e($errors->first('image_miniature')); ?></strong>
        <?php endif; ?>

        <p>Image de fond d'écran : (facultatif) </p>
        <input type="file" class="form-control-file" id="image_background" name="image_background"><br>
        

        <input class="btn btn-primary" type="submit" value="Créer"/>
    </form> 
<?php endif; ?>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/icm1/ruffieum/Documents/cours web/cote serveur/laravel_projects/laravel_series-main/resources/views/createSerie.blade.php ENDPATH**/ ?>