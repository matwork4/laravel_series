        



<?php $__env->startSection('content'); ?>
<h1>La série : <?php echo e($serie->title); ?> </h1>
        
<p>Résumé : <?php echo e($serie->description); ?> </p>
<p>Acteurs : <?php echo e($serie->actors); ?> </p>

<p>Auteur :  
    <button class="btn btn-primary"
    onclick="location.href='/profile/<?php echo e($serie->user->id); ?>'">
        <?php echo e($serie->user->username); ?>

    </button>
</p>

<p>Commentaires : 
    <?php $__currentLoopData = $serie->comment; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <br>
        <p><?php echo e($c->contenu); ?></p>
        <p>Par <?php echo e($c->user->username); ?></p>
        <p>Le <?php echo e($c->created_at); ?></p>

        <!-- Supprimer un commentaire si il nous appartient -->
        <?php if(auth()->guard()->guest()): ?>
        <?php else: ?>
            <?php if($c->user_id == auth()->user()->id ): ?>
            <form action="/c_remove" enctype="multipart/form-data" method="post">  
                <?php echo csrf_field(); ?>
                <input type='hidden' name='serie_id' value='<?php echo e($serie->id); ?>' />
                <input type='hidden' name='comment_id' value='<?php echo e($c->id); ?>' />
                <input class="btn btn-primary" type="submit" value="Supprimer"/>
            </form>
            <?php endif; ?>
        <?php endif; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>
        
<?php if(auth()->guard()->guest()): ?>
    <p>Connectez vous pour ajouter un commentaire : 
        <button class="btn btn-primary"
        onclick="location.href='/login'">
        Se connecter</button></p>
            
<?php else: ?>
            
    <form action="/c" enctype="multipart/form-data" method="post">
        <?php echo csrf_field(); ?>
        <label for="commentaire">Ajouter un commentaire :</label><br>
        <input type="text" id="contenu" name="contenu" value=""><br><br>
        <!-- Permet de passer l'id de la série -->
        <input type='hidden' name='serie_id' value='<?php echo e($serie->id); ?>' /> 
        <input class="btn btn-primary" type="submit" value="Poster"/>
    </form> 
<?php endif; ?>

<?php $__env->stopSection(); ?>



<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/icm1/ruffieum/Documents/cours web/cote serveur/laravel_projects/laravel_series-main/resources/views/uneSerie.blade.php ENDPATH**/ ?>