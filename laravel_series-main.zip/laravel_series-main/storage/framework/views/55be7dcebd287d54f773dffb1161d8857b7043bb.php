<?php $__env->startSection('content'); ?>
<h1>Series</h1>
<div><img src="/assets/icon_camera.png" alt=""></div>

<p>Liste des séries :
    <?php $__currentLoopData = $serie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <br>
        <button class="btn btn-primary"
        onclick="location.href='/series/<?php echo e($s->id); ?>'">
            <?php echo e($s->title); ?>

        </button>
        
        <?php echo e($s->description); ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</p>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts/main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/icm1/ruffieum/Documents/cours web/cote serveur/laravel_projects/laravel_series-main/resources/views/series.blade.php ENDPATH**/ ?>