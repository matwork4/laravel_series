
        @extends('layouts/main')

        @section('content')
        <h1>Home</h1>
        @endsection

